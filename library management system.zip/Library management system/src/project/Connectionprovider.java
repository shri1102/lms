

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.*;

/**
 *
 * @author Raam
 */


public class Connectionprovider {
    public static void main(String[] args){
    
        String url="jdbc:mysql://localhost:3306/lms";
        String username="root";
        String password="raamshri";
    
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(url,username,password);
            
            System.out.println(con);
            
        }
        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println(e);
        }
    }    

    public static Connection getCon() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
           
           
    
     
    


    
